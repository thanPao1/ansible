# crowdstrike

Gate de seguridad que valida, contra la REST API de CrowdStrike Falcon, que
un host recién provisionado tenga el sensor instalado con un AID activo
antes de continuar el flujo de orquestación.

## Estructura

```
crowdstrike/
├── crowdstrike-main.yml              # punto de entrada (referenciado en AAP)
├── crowdstrike-tasks/
│   ├── crowdstrike-pretasks.yml       # validaciones + autenticación OAuth2
│   ├── crowdstrike-run.yml            # consulta del AID + validación de estado
│   └── crowdstrike-postasks.yml       # resultado final del gate
├── vars/
│   └── main.yml                       # endpoints y parámetros (retries, delay, etc.)
└── README.md
```

## Variables requeridas (inyectadas en runtime, no viven en el repo)

| Variable | Origen esperado | Sensible |
|---|---|---|
| `cs_client_id` | AAP Credential | Sí |
| `cs_client_secret` | AAP Credential | Sí |
| `target_hostname` | Inventario / extra_vars | No |

## Pendientes antes de productivo (seguimiento con EDR)

- [ ] Confirmar región/base_url real (`vars/main.yml`)
- [ ] Confirmar campo de filtro: hostname vs local_ip (`vars/main.yml`)
- [ ] Confirmar formato exacto del hostname reportado por el sensor
- [ ] Confirmar valor de `status` = activo (`vars/main.yml`, hoy asume `"normal"`)
- [ ] Confirmar si se debe validar también `reduced_functionality_mode`
- [ ] Confirmar tiempo de propagación para calibrar `crowdstrike_gate_retries` / `crowdstrike_gate_delay_seconds`
- [ ] Credenciales reales (Client ID / Secret) ya regeneradas y cargadas como Credential en AAP
